# Changelog

## Version 0.1.1

- Allow cancelling in between band processing

## Version 0.1

- First version
